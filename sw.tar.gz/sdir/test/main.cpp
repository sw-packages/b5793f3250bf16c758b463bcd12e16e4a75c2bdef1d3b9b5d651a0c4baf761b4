#define CATCH_CONFIG_MAIN
#include <iostream>
#include <tests.hpp>